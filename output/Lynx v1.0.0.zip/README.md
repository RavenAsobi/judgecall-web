# Lynx 浏览器插件 v1.0.0

从 GEM、melee.gg、EventLink 当前打开的页面提取赛事桌台 JSON，供 Lynx 网页导入。GEM 赛事的英雄数据仍可单独提取。

## 安装

1. 解压 `Lynx v1.0.0.zip` 到固定目录，不要直接把 ZIP 拖入浏览器。
2. 在 Chrome 地址栏打开 `chrome://extensions`，开启“开发者模式”。
3. 点击“加载已解压的扩展程序”，选择解压后**含有 `manifest.json` 的目录**。
4. 建议先停用旧版 Lynx 插件，避免点错图标；确认新版可用后再移除旧版。

## 导入赛事结果

1. 在 GEM `/report`、melee.gg 或 EventLink 的配对/成绩页面打开插件，点击“读取当前页面桌台”。
2. 核对预览的桌数、桌号范围。插件只读当前页面 DOM；若有分页、筛选或未显示的桌台，应先在来源网站完整显示。特别注意：Lynx 每轮首次导入会直接按 JSON 桌号清单重设总桌数。
3. 勾选确认后，通常点击“复制普通 JSON”，粘贴到 Lynx 的导入框。普通 JSON 不会自动增加轮数。
4. 只有确认要开始下一轮，且源页面为完整、连续、未上报、无 Drop、无加时的新配对表时，才展开“需要开始新一轮”，填写 Lynx 赛事设置中的起始桌号，再复制新一轮 JSON。正序是最小桌号，倒序是最大桌号。首轮首次导入应使用普通 JSON。

配对 JSON 继续沿用 v0.4.0 的安全开轮规则。v1.0.0 新增玩家 ID 覆盖率预览及 `playerIdNamespace1/2` 字段：GEM 使用 `gem-player-id`，Melee 配对页使用 `melee-player-card`，EventLink 无已验证 ID 时保持 `null`，绝不按姓名伪造 ID。旧版 Lynx 导入框会忽略新增字段，所以它**尚不会把玩家 ID 存入服务器**。

## 导出排名与积分

1. 展开“排名与积分导出（1.0 新增）”。选择赛事来源。
2. 可在来源网站的排名页面点击“读取当前页可见表格”，或打开来源网站导出的 CSV。插件不访问未公开的私有 API，不跨分页抓取；CSV 支持 UTF-8 和 GB18030。
3. 核对姓名、积分、玩家 ID、名次等列映射，输入**积分所属的已完成轮次**。例如将第一轮结束后的排名用于第二轮抽桌，应填 `1`；开赛前的 0 分榜可填 `0`。
4. 核对 ID 类型。不能假定 Melee 排名 CSV 的 `Wizards Account ID` 与配对页 `data-id` 是同一种 ID；核实前不可自动合并。没有 ID 的排名仍能导出，但同名玩家需要人工确认。
5. 点击“校验并预览”，确认玩家数、ID 覆盖和积分范围后，再复制独立的 `lynx-standings-v1` JSON。

积分 JSON 示例：`{ "schema":"lynx-standings-v1", "source":"melee", "roundCompleted":1, "idNamespace":"wizards-account", "rows":[{"name":"Alice","playerId":"...","points":3,"rank":2}] }`。此数据**不能粘贴进当前 Lynx 网页的桌台导入框**；网页端的玩家资料、积分导入和套牌检查功能需在下一阶段实现。当前排名页是否有足够的可见列取决于来源平台，若无法识别请使用 CSV 或提供脱敏样本完善专用适配。

## 构建与测试

在 `Lynx/extension` 目录执行 `npm ci`、`npm test`、`npm run typecheck`、`npm run build`；构建输出在 `dist`。测试命令需要 Node.js 22 或更新版本。

EventLink 的 `0:0 DRAW` 可以被插件导出为有效成绩；Lynx 网页端需包含 `web/src/import-utils.js` 的 `hasReportedResult` 修正，才会将其显示为已回报。本版插件交付**不代表线上 Lynx 网页或公开下载页已经部署更新**。
