const STORAGE_KEYS = {
  TOURNAMENT_NAMES: "TOURNAMENT_NAMES"
};
async function getStorage(key) {
  const result = await chrome.storage.local.get(key);
  return result[key];
}
async function setStorage(key, value) {
  await chrome.storage.local.set({ [key]: value });
}
async function getTournamentNames() {
  return await getStorage(STORAGE_KEYS.TOURNAMENT_NAMES) || {};
}
async function setTournamentName(gemId, name) {
  const names = await getTournamentNames();
  names[gemId] = name;
  await setStorage(STORAGE_KEYS.TOURNAMENT_NAMES, names);
}
chrome.runtime.onInstalled.addListener(() => {
  console.log("[Lynx] 扩展已安装/更新");
});
chrome.webNavigation.onCompleted.addListener(
  ({ url, tabId }) => {
    const isReport = url.includes("/report");
    const isRun = url.includes("/run") && !isReport;
    const [, gemId] = url.match(/.*\/gem\/(\d+).*/) || [];
    if (isRun && gemId) {
      chrome.scripting.executeScript(
        {
          target: { tabId },
          func: () => document.querySelector("h1")?.innerText || ""
        },
        (results) => {
          const name = results?.[0]?.result;
          if (name) {
            setTournamentName(gemId, name);
          }
        }
      );
    }
  },
  { url: [{ hostContains: "gem.fabtcg.com" }] }
);
